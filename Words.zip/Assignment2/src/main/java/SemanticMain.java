import org.apache.commons.lang3.time.StopWatch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SemanticMain {
    public List<String> listVocabulary = new ArrayList<>();  //List that contains all the vocabularies loaded from the csv file.
    public List<double[]> listVectors = new ArrayList<>(); //Associated vectors from the csv file.
    public List<Glove> listGlove = new ArrayList<>();
    public final List<String> STOPWORDS;

    public SemanticMain() throws IOException {
        STOPWORDS = Toolkit.loadStopWords();
        Toolkit.loadGLOVE();

    }


    public static void main(String[] args) throws IOException {
        StopWatch mySW = new StopWatch();
        mySW.start();
        SemanticMain mySM = new SemanticMain();
        mySM.listVocabulary = Toolkit.getListVocabulary();
        mySM.listVectors = Toolkit.getlistVectors();
        mySM.listGlove = mySM.CreateGloveList();

        List<CosSimilarityPair> listWN = mySM.WordsNearest("computer");
        Toolkit.PrintSemantic(listWN, 5);

        listWN = mySM.WordsNearest("phd");
        Toolkit.PrintSemantic(listWN, 5);

        List<CosSimilarityPair> listLA = mySM.LogicalAnalogies("china", "uk", "london", 5);
        Toolkit.PrintSemantic("china", "uk", "london", listLA);

        listLA = mySM.LogicalAnalogies("woman", "man", "king", 5);
        Toolkit.PrintSemantic("woman", "man", "king", listLA);

        listLA = mySM.LogicalAnalogies("banana", "apple", "red", 3);
        Toolkit.PrintSemantic("banana", "apple", "red", listLA);
        mySW.stop();

        if (mySW.getTime() > 2000)
            System.out.println("It takes too long to execute your code!\nIt should take less than 2 second to run.");
        else
            System.out.println("Well done!\nElapsed time in milliseconds: " + mySW.getTime());
    }

    public List<Glove> CreateGloveList() {
        List<Glove> listResult = new ArrayList<>();
        //TODO Task 6.1
        for (int i = 0; i < listVocabulary.size(); i++) {
            if (!STOPWORDS.contains(listVocabulary.get(i))) {
                listResult.add(new Glove(listVocabulary.get(i), new Vector(listVectors.get(i))));
            }
        }
        listGlove = listResult;

        return listGlove;

    }


    public List<CosSimilarityPair> WordsNearest(String _word) {
        List<CosSimilarityPair> listCosineSimilarity = new ArrayList<>();
        //TODO Task 6.2
        Glove result = null;
        Glove newglove = null;
        //word存在
        for (int i = 0; i < listGlove.size(); i++) {
            if (listGlove.get(i).getVocabulary().equals(_word)) {
                result = listGlove.get(i);
            }
            if (listGlove.get(i).getVocabulary().equals("error")) {
                newglove = listGlove.get(i);
            }
        }
        //result设置error
        if (result == null) {
            result = newglove;
        }

        for (int i = 0; i < listGlove.size(); i++) {
            if (!result.getVocabulary().equals(listGlove.get(i).getVocabulary())) {
                Vector ve = listGlove.get(i).getVector();
                double cs = ve.cosineSimilarity(result.getVector());
                listCosineSimilarity.add(new CosSimilarityPair(result.getVocabulary(), listGlove.get(i).getVocabulary(), cs));
            }
        }
        HeapSort.doHeapSort(listCosineSimilarity);
        return listCosineSimilarity;
    }


    public List<CosSimilarityPair> WordsNearest(Vector _vector) {
        List<CosSimilarityPair> listCosineSimilarity = new ArrayList<>();
        //TODO Task 6.3

        for (int i = 0; i < listGlove.size(); i++) {
            if (!_vector.equals(listGlove.get(i).getVector())) {
                Vector ve = listGlove.get(i).getVector();
                double cs = ve.cosineSimilarity(_vector);
                listCosineSimilarity.add(new CosSimilarityPair(_vector, listGlove.get(i).getVocabulary(), cs));
            }
        }
        HeapSort.doHeapSort(listCosineSimilarity);
        return listCosineSimilarity;
    }

    /**
     * Method to calculate the logical analogies by using references.
     * <p>
     * Example: uk is to london as china is to XXXX.
     * _firISRef  _firTORef _secISRef
     * In the above example, "uk" is the first IS reference; "london" is the first TO reference
     * and "china" is the second IS reference. Moreover, "XXXX" is the vocabulary(ies) we'd like
     * to get from this method.
     * <p>
     * If _top <= 0, then returns an empty listResult.
     * If the vocabulary list does not include _secISRef or _firISRef or _firTORef, then returns an empty listResult.
     *
     * @param _secISRef The second IS reference
     * @param _firISRef The first IS reference
     * @param _firTORef The first TO reference
     * @param _top      How many vocabularies to include.
     */
    public List<CosSimilarityPair> LogicalAnalogies(String _secISRef, String _firISRef, String _firTORef, int _top) {
        List<CosSimilarityPair> listResult = new ArrayList<>();
        //TODO Task 6.4
        Glove secIsRef = null;
        Glove firISRef = null;
        Glove firTORef = null;
        Vector ve = null;
        List<CosSimilarityPair> list2 = new ArrayList<>();


        if (_secISRef == null || _firISRef == null || _firTORef == null) {
            return list2;
        }

        for (int i = 0; i < listGlove.size(); i++) {
            if (listGlove.get(i).getVocabulary().equals(_secISRef)) {
                secIsRef = listGlove.get(i);
            }

            if (listGlove.get(i).getVocabulary().equals(_firISRef)) {
                firISRef = listGlove.get(i);


            }
            if (listGlove.get(i).getVocabulary().equals(_firTORef)) {
                firTORef = listGlove.get(i);

            }
        }

        if (secIsRef == null || firTORef == null || firISRef == null) {
            return list2;
        }

        ve = secIsRef.getVector().subtraction(firISRef.getVector()).add(firTORef.getVector());
        List<CosSimilarityPair> list = WordsNearest(ve);
        for (int i = 0; i < list.size(); i++) {
            if ((_firISRef.equals(list.get(i).getWord2())) || (_firTORef.equals(list.get(i).getWord2())) || (_secISRef.equals(list.get(i).getWord2()))) {
                list.remove(list.get(i));
            }
        }
        if (_top > 0) {
            for (int i = 0; i < _top; i++) {
                list2.add(list.get(i));
            }
        } else {
            return list2;
        }
        return list2;
    }
}